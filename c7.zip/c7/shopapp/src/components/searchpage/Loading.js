import React, { useEffect } from 'react';
export const Loading = (props)=>{
    useEffect(()=>{
        console.log('----> LOADING DID MOUNT $$$$$$$$');
        return ()=>{
            console.log('--->LOADING UN MOUNT ************');
        }
    },[]);
    return (
        <p>Loading....</p>
    );

}