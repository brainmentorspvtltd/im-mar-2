export const ActionCreator = (data, name)=>{
    return {
        payload: data,
        type: name
    }
}