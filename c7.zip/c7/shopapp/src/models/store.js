import {createStore} from 'redux';
import { ProductReducer } from '../helpers/productreducer';
export const store = createStore(ProductReducer);
store.subscribe(()=>{
    console.log('State Updated.... ', store.getState());
})