import React, {Component, PureComponent} from 'react';
import  Items  from '../components/searchpage/Items';
import { Loading } from '../components/searchpage/Loading';
import { Total } from '../components/searchpage/Total';
import { TotalItemsInCart } from '../components/searchpage/TotalItemsInCart';
import { getProducts } from '../utils/ajax';
import {CommonContext} from '../utils/commoncontext';
export class SearchPage  extends PureComponent{

//extends Component{
    constructor(props){
            super(props);

            console.log("1. Constructor Call");
            this.state = {'products':[]};
            this.itemsInCart = 0;
            this.isLoading = true;
    }
    /*UNSAFE_componentWillMount(){
        console.log("2. Component WillUnMOUNT");
        // Async Code (Non Blocking) // AJax
    }*/

    updateCart(val){
        console.log('Update Cart Called...',this);
        this.itemsInCart+=val;
        console.log('After Update Cart Called...',this.itemsInCart);
        this.setState({...this.state});

    }
    /*shouldComponentUpdate(nextProps, nextState){
        if(this.props !== nextProps && this.state !== nextState){
            return true;
        }
        else{
            return false;
        }
    }*/
    render(){
        console.log("3. Render..... ",this.isLoading);
        let jsx = (<CommonContext.Provider value={{cartTotal:this.itemsInCart,updateCart:this.updateCart.bind(this) }}>
        <TotalItemsInCart/>
        <hr/>
        <Items items = {this.state.products}/>
        <Total total = {this.state.products.length}/>
  </CommonContext.Provider>);
        return (
            <>
                {this.isLoading?<Loading/>:jsx}
            </>
        )
    }
    componentDidUpdate(){

    }
    componentWillUnmount(){
        // clean up code
    }
    componentDidMount(){
       // ajax call
      // this.loading = true;
      const promise = getProducts();
        setTimeout(()=>{

            promise.then(response=>{
                this.isLoading = false;
                console.log(response.data.mobiles);
                this.setState({'products':response.data.mobiles})
            }).catch(err=>{
                console.log('Ajax Call ',err);
            })
        },9000)


    //    promise.then(response=>{
    //         response.json().then(data=>{
    //             console.log('Data Rec from Server ',data);
    //             this.setState({'products':data.mobiles})
    //         }).catch(err=>{
    //             console.log('JSON parse Error ',err);
    //         })
    //    }).catch(err=>{
    //        console.log('Response Error ',err);
    //    })
        console.log('4. Component Did Mount...');
    }

}