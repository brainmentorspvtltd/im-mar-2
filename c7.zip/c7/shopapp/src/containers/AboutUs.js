import React from 'react';
export const About = (props)=>{
    return (<h1>I am About Page</h1>)
}