const http = require('http');
const staticFileObj = require('./utils/filereader');
const server = http.createServer((request, response)=>{
    console.log('Request come ',request.url);
    let url = request.url;
    if(url=='/' ){
        url = '/index.html';

    }
    if(staticFileObj.isStaticFile(url)){
        // Static File
        staticFileObj.readStaticFile(url,response);
    }
    else{
    response.writeHead(200,{'content-type':'text/html'});
    response.write('<h1>Hello - Client...</h1>');
    response.end();
    }
});
server.listen(process.env.PORT || 5555,()=>{
    console.log('Server Started...');
})