const mysql = require('mysql');
const dbOperations = {

    connection(){
        let con = mysql.createConnection({
            host:'localhost',
            user:'root',
            password:'amit123456',
            database:'shopim'
        });
        con.connect((err)=>{
            if(err){
                console.log(err);
                throw err;
            }
            else{
                console.log('Connection created...');
            }
        });
        return con;
    },
    addProduct(product){
        let con = this.connection();
        const SQL = "insert into products SET ?";
        con.query(SQL, product, (err,result)=>{
            if(err){
                throw err;
            }
            else{
                console.log(result);
            }
        })
    },
    getProducts(){
        const SQL ='select id, name, price, url from products';
        let con = this.connection();
        con.query(SQL, (err, rows)=>{
            if(err){
                throw err;
            }
            else{
                rows.forEach(row=>console.log(row));
            }
        });
        con.end();
    }
}

//dbOperations.connection();
dbOperations.addProduct({id:1009, name:'Nokia',price:4343,url:'https://cdn.vox-cdn.com/thumbor/SJcmPEheS_cbdujd4zbIPTpuXfg=/1400x1400/filters:format(jpeg)/cdn.vox-cdn.com/uploads/chorus_asset/file/13315959/akrales_181019_3014_0770.jpg'});
//dbOperations.getProducts();