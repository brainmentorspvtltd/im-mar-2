const fs = require('fs');
const path = require('path');
 function readStaticFile(url, response){
    const parentDirPath = path.normalize(__dirname+'/..');
    const fullPath= path.join(parentDirPath,'/public',url);
    const readStream = fs.createReadStream(fullPath);
    readStream.pipe(response);
}

function isStaticFile(fileName){
    const extensions = ['.html','.css',
    '.png','.jpeg','.jpg','.js'];
    let extension = path.extname(fileName);
    let index = extensions.indexOf(extension);
    return index>=0;
}

module.exports = {
    readStaticFile,isStaticFile
}