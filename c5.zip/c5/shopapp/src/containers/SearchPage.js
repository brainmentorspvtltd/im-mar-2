import React, {Component} from 'react';
import { Items } from '../components/searchpage/Items';
import { Total } from '../components/searchpage/Total';
import { TotalItemsInCart } from '../components/searchpage/TotalItemsInCart';
import { getProducts } from '../utils/ajax';
import {CommonContext} from '../utils/commoncontext';
export class SearchPage extends Component{
    constructor(props){
            super(props);
            console.log("1. Constructor Call");
            this.state = {'products':[]};
            this.itemsInCart = 0;
    }
    /*UNSAFE_componentWillMount(){
        console.log("2. Component WillUnMOUNT");
        // Async Code (Non Blocking) // AJax
    }*/

    updateCart(val){
        console.log('Update Cart Called...',this);
        this.itemsInCart+=val;
        console.log('After Update Cart Called...',this.itemsInCart);
        this.setState({...this.state});

    }
    render(){
        console.log("3. Render");
        return (
            <>
            <CommonContext.Provider value={{cartTotal:this.itemsInCart,updateCart:this.updateCart.bind(this) }}>
                  <TotalItemsInCart/>
                  <hr/>
                  <Items items = {this.state.products}/>
                  <Total total = {this.state.products.length}/>
            </CommonContext.Provider>
            </>
        )
    }
    componentDidMount(){
       // ajax call
       const promise = getProducts();
       promise.then(response=>{
            response.json().then(data=>{
                console.log('Data Rec from Server ',data);
                this.setState({'products':data.mobiles})
            }).catch(err=>{
                console.log('JSON parse Error ',err);
            })
       }).catch(err=>{
           console.log('Response Error ',err);
       })
        console.log('4. Component Did Mount...');
    }

}