import React from 'react';
export const AddProduct = (props)=>{
    return (<h1>I am Add Product Page</h1>)
}