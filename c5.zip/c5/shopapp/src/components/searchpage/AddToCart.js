import React, { useState } from 'react';
import { CommonContext } from '../../utils/commoncontext';
//let val = "Add To Cart";
export const AddToCart = (props)=>{
    console.log('Render Add to Cart Happen');

    const [toggle, setToggle]= useState(false); // this.state = {toggle:false}
    //this.setState(); // Async
    const toggleIt = ()=>{
        //val = !toggle?'Remove From Cart':'Add to Cart';
        setToggle(!toggle);
        // toggle = !toggle (Mutable)
        console.log('Toggle It Called...');
    }
    return (
        <CommonContext.Consumer>{
                (context)=><button onClick={()=>{
                    toggleIt();
                    context.updateCart(!toggle?1:-1);
                }} className='btn btn-primary'>{toggle?'Remove From cart':'Add to Cart'}</button>
            }

        </CommonContext.Consumer>
    )
}