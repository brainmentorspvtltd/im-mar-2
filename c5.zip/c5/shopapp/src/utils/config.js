export const CONFIG = {
    //PRODUCTS_URL : 'https://raw.githubusercontent.com/brainmentorspvtltd/myserverdata/master/productsdata.json'
    PRODUCTS_URL :'https://raw.githubusercontent.com/brainmentorspvtltd/myserverdata/master/mobiles.json'
}