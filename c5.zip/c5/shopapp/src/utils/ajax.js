import { CONFIG } from "./config";

export function getProducts(){
    let promise = fetch(CONFIG.PRODUCTS_URL,{method:'GET'});
    return promise;
}