export const ProductReducer = (state = {products:[]},action)=>{
    if(action.type=='ADD'){
        let products = state.products;
        products.push(action.payload);
        return {'products':products};
    }
    return state;
}