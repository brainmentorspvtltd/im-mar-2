import React, { useRef } from 'react';
import { ActionCreator } from '../helpers/actioncreator';
import { store } from '../models/store';
export const AddProduct = (props)=>{
    let id = useRef(0);
    let name = useRef('');
    let price = useRef(0);
    let url = useRef('');
    const clearAll = ()=>{
        id.current.value = '';
        name.current.value = '';
        price.current.value = '';
        url.current.value = '';
    }
    const addProduct = ()=>{
        const product = {
            id: id.current.value,
            name : name.current.value,
            price : price.current.value,
            url: url.current.value
        }
        let actionObject = ActionCreator(product, 'ADD');
        store.dispatch(actionObject);
        console.log(product);
    }

    return (<>
            <div className = 'form-group'>
                <label>Id</label>
                <input ref={id} className = 'form-control' type='text' placeholder='Type Id '/>
            </div>
            <div className = 'form-group'>
                <label>Name</label>
                <input ref={name} className = 'form-control' type='text' placeholder='Type Name '/>
            </div>
            <div className = 'form-group'>
                <label>Price</label>
                <input ref={price} className = 'form-control' type='text' placeholder='Type Price '/>
            </div>
            <div className = 'form-group'>
                <label>URL</label>
                <input ref={url} className = 'form-control' type='text' placeholder='Type URL '/>
            </div>
            <br/>
            <div className = 'form-group'>
                <button onClick={addProduct} className = 'btn btn-primary me-2'>Add</button>
                <button onClick={clearAll} className = 'btn btn-secondary'>Clear All</button>
            </div>

    </>)
}