import React from 'react';
import { Route, Switch } from 'react-router';
import { Menu } from '../components/Menu';
import { About } from './AboutUs';
import { AddProduct } from './AddProduct';
import { Home } from './Home';
import { SearchPage } from './SearchPage';
export const Shop = (props)=>{
    return (
        <div className = 'container'>
            <Menu/>
            <Switch>
                <Route exact path="/" component={Home}/>
                <Route exact path="/products" component={SearchPage}/>
                <Route exact path="/about" component={About}/>
                <Route exact path="/add" component={AddProduct}/>
            </Switch>
            {/* <SearchPage/> */}
        </div>
    )
}