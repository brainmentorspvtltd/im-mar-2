import React from 'react';
export const CommonContext = React.
createContext({cartTotal:0, updateCart:function(){}});
