import React from 'react';
import { connect } from 'react-redux';
import { Item } from './Item';
const Items = (props)=>{
    let jsx  = (<></>);
    if(props.myitems){
        jsx = props.myitems.map(item=><Item key={item.id} item = {item}/>);
    }
    return (
        <>
            {props.items.map(item=><Item key={item.id} item = {item}/>)}
            <hr/>
            {jsx}

        </>
    )
}
const mapStateToProps = (state)=>{
    return {
        'myitems':state.products
    }
}
// const hoc = connect(mapStateToProps);
// hoc(Items);
export default connect(mapStateToProps)(Items)

