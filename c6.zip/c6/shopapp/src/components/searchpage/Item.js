import React from 'react';
import { AddToCart } from './AddToCart';
export const Item = (props)=>{
    const style = {
        width:'100px',
        height:'100px'
    }
    return (
        <div>
            <img style={style} src={props.item.url}/>
            <p>Name {props.item.name}  Price {props.item.price} <AddToCart/>  </p>

            <br/>
        </div>
    )
}