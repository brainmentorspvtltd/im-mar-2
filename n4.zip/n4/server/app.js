const http = require('http');
const staticFileObj = require('./utils/filereader');
const db = require('./utils/db');
const cors= require('./utils/cors');
const server = http.createServer((request, response)=>{
    cors(response);
    console.log('Request come ',request.url);
    let method = request.method;
    let url = request.url;
    if(url=='/' ){
        url = '/index.html';

    }

    if(staticFileObj.isStaticFile(url)){
        // Static File
        staticFileObj.readStaticFile(url,response);
    }
    else
    if(url =='/addproduct' && method=='POST'){
        let postdata = '';
        request.on('data',(chunk)=>{
            postdata+=chunk;
        });
        request.on('end',()=>{
            console.log('Post Data ',postdata);
            let product = JSON.parse(postdata);
            const promise = db.addProduct(product);
            promise.then(data=>{
                response.write(JSON.stringify(data));
                response.end();
            }).catch(err=>{
                response.write(JSON.stringify({"err":"Not Added"+err}));
                response.end();
            })
        });
    }
    else
    if(url =='/products' && method == 'GET'){
            const promise = db.getProducts();
            promise.then(products=>{
                    let object = {"products":products};
                    let json = JSON.stringify(object);
                    console.log(json);
                    response.write(json);
                    response.end();
            }).catch(err=>{
                    response.write({"products":[],'msg':'DB Operation Fail '+err});
                    response.end();
                    })
    }
    else{
    response.writeHead(200,{'content-type':'text/html'});
    response.write('<h1>OOPS U Type Something Wrong...</h1>');
    response.end();
    }
});
server.listen(process.env.PORT || 5555,()=>{
    console.log('Server Started...');
})