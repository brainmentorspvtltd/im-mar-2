import { CONFIG } from "./config";
import axios from 'axios';
export function getProducts(){
    console.log('Ajax Call ....');
    //let promise = fetch(CONFIG.PRODUCTS_URL,{method:'GET'});
    // in form of querystring
    let promise = axios.get(CONFIG.PRODUCTS_URL);
    //let promise = axios.post('URL',{'userid':'amit','password':'a1111'});
    return promise;
}