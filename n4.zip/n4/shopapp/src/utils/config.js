export const CONFIG = {
    //PRODUCTS_URL : 'https://raw.githubusercontent.com/brainmentorspvtltd/myserverdata/master/productsdata.json'
    //PRODUCTS_URL :'/myserverdata/master/mobiles.json'
    PRODUCTS_URL:'/products'
}