import axios from 'axios';
export function loadConfig(){
    axios.defaults.baseURL='http://localhost:5555';
//axios.defaults.baseURL = 'https://raw.githubusercontent.com/brainmentorspvtltd';
//axios.defaults.headers.post['Content-Type']='application/json';
let tokenInterceptor = axios.interceptors
.request.use(config=>{
    console.log('Interceptor Callled...');
config.tokenId = 'A111'; // localStorage.token
return config;
},err=>{
    console.log('Request Err ',err);
})
setTimeout(()=>{
    axios.interceptors.request.eject(tokenInterceptor);
    console.log("Interceptor Ejected....");
},9000);

}