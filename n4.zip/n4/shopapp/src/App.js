import React from 'react';
import { Shop } from './containers/Shop';
const App = (props)=>{
  return (
    <>
    <Shop/>
    </>
  )
}
export default App;