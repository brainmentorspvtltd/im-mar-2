import React from 'react';
import { CommonContext } from '../../utils/commoncontext';
export const TotalItemsInCart = (props)=>{
    return (
        <CommonContext.Consumer>
            {
                (context)=><p>Total Items in Cart {context.cartTotal}</p>
            }

        </CommonContext.Consumer>
    )
}