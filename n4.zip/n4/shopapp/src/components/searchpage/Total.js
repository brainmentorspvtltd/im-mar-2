import React from 'react';
export const Total = (props)=>{
    return (<p>Total Items are {props.total}</p>)
}