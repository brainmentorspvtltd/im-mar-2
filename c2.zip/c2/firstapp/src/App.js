import React, { Component } from 'react';
import './App.css';
import { Footer } from './components/Footer';
import {Header} from './components/Header';


class App extends Component {
  constructor(){
    super();
    console.log('1. Constructor Call  ',this);
    this.names = ['Ram','Amit','Shyam'];
    this.count = 0;
    this.message = 'Count is '+this.count;
    this.state = {msg:this.message};
    console.log('After Setting the State ',this);
  }

  plusIt(){
    //console.log('this is ',this);
    // >20 Green < 10 Red else yellow
    this.count++;
    this.message = 'Count is '+this.count;
    //console.log('PlusIt Call ',this.count);
    this.setState({msg:this.message}); // Immutable

  }

  render(){
    console.log('2. Render Call');
    let myClass = 'yellow';
    if(this.count<10){
      myClass = 'red';
    }
    else
    if(this.count>20){
      myClass = 'green';
    }

    const myStyle = {
      backgroundColor:'red',
      color:'yellow'
    }
    let title  = 'Hello React JS.....';
    return (
      <div>
      <p>I am a Header</p>
      {this.count>10?<h1 style={myStyle}>{title}</h1>:<p>OK React JS</p>}
      {/* {flag<Login/>:<Register/>} */}
      <p>Print Names</p>
      <ul>
      {this.names.map((name,index)=><li key={index}>{name}</li>)}
      </ul>

    <h1 className={myClass}>{this.state.msg}</h1>

    <button onClick={this.plusIt.bind(this)}>Plus</button>
    <Footer/>
    </div>
    )
  }

}
export default App;

/*
const message = ()=>"Hi React JS $$$$$$";

 const MAX  = 100;
  const App=()=>{
  // <body bgcolor> <input type='text' placeholder=''/>
  // <h1 >Hello ReactJS</h1>
  const myStyle = {
    backgroundColor:'red',
    color:'yellow'
  }
  let title  = 'Hello React JS.....';
  return (
    <div>
      <Header/>
    <h1 style={myStyle}>{title}</h1>
    <h1 className='red'>{message()}</h1>
    <Footer/>
    </div>
    /*
    React.createElement('div',null,
      React.createElement('h1',null,'Hello ReactJS'),
      React.createElement('h1',null,'Hi ReactJS')
      )*/

/*
  );
}
// const OBJ = {
//   App, MAX
// }
//export default OBJ;
*/



//export default App;