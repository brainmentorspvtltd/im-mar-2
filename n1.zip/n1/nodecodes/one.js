function add(a=0,b=0){
    return a + b;
}
console.log(add(100,200));
console.log(__dirname); // current dir location
console.log(__filename); // current file location
// var a= 100;
// var b = 200;
// var c = a + b;
// console.log(c);