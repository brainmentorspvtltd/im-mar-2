const fn = require('./one');
console.log(fn(1000,2000));