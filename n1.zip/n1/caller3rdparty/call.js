const obj = require('srcalc');
console.log(obj.add(10,2));
console.log(obj.subtract(1,2));