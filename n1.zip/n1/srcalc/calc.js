const calc = {
    add(x,y){
       return  require('./adder')(x,y);
    },
    subtract(x,y){
        return x - y;
    }
}
module.exports = calc;