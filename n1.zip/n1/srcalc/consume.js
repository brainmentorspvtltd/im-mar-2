const calc = require('./calc');
console.log(calc.add(100,200));
console.log(calc.subtract(100,200));