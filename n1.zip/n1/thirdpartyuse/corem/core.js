const fs = require('fs');
//const filePath = __filename;
const path = require('path');
console.log('Current Dir ',__dirname);
const parent = path.normalize(__dirname+"/..");
console.log('Parent ',parent);
const fullPath = path.join(parent,'/logics/index.js');
console.log('Full Path is ',fullPath);
//fs.stat()
//const path = '/Users/amit/Documents/react-application-codes/thirdpartyuse/index.js';
/*function callBack(error, content){
    if(error){
        console.log('Error occur ',error);
    }
    else{
        console.log(content);
        //console.log(content.toString());
    }
}*/
console.log('Before read');
// Async
fs.readFile(fullPath,(error, content)=>{
    if(error){
        console.log(error);
    }
    else{
        console.log(content.toString());
    }
})
//fs.readFile(path, callBack);
console.log('After read');