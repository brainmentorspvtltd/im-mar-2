const fs = require('fs');
console.log('Before');
fs.readFile('/Users/amit/Documents'
+'/react-application-codes/thirdpartyuse/corem/core.js'
,(err, content)=>{
    console.log(err?'error'+err:'FIRST '+content);
});
const p = '/Users/amit/Documents/react-application-codes/thirdpartyuse/corem/write.js';
fs.readFile(p, (err, content)=>{
    console.log(err?'error'+err:'SECOND '+content);
});
console.log('After');