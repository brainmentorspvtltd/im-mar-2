const fs = require('fs');
const filePath = '/Users/amit/Documents/softwares/Xcode_11.5.xip';
console.log('Before');
const targetPath = '/Users/amit/Documents/softwares/Xcode_11.5Clone.xip';
const rstream = fs.createReadStream(filePath,{highWaterMark:20});
const wstream = fs.createWriteStream(targetPath);
rstream.on('open',()=>{
    console.log('Stream Open');
})
//rstream.pipe(wstream);
rstream.on('data',(chunk)=>{
    console.log(chunk);
    //wstream.write(chunk);
});
rstream.on('error',(err)=>console.log(err));
rstream.on('end',()=>{
    console.log('COPY DONE....');
});
rstream.on('close',()=>{
    console.log('Close..');
})
// fs.readFile(filePath, (err, content)=>{
//     if(err){
//         console.log(err);
//     }
//     else{
//         console.log(content);
//     }
// });
console.log('After');