const fs = require('fs');
console.log('Before read');
try{
const content = fs.readFileSync(__filename); // Sync (Block)
console.log(content.toString());
}
catch(err){
    console.log(err);
}
console.log('After Read');
try{
fs.writeFileSync('www.txt','gkfjgkfd');
console.log('Write Done...');
}
catch(e){
    console.log(e);
}
/*
fs.readFile(__filename, (err, content)=>{

})
*/

// Async
// fs.writeFile('abcd.txt','Hello Node JS',(err=>{
//     console.log(err?'Error '+err:'Write Done');
// }))