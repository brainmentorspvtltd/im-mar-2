const chalk = require('chalk');
console.log(__filename);
console.log(__dirname);
console.log(chalk.green.bold.underline('Hello Node JS'));