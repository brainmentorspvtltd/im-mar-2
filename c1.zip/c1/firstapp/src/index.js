import ReactDOM from 'react-dom';
//import {App, MAX} from './App';
import App from './App';
//import OBJ from './App';
import React from 'react';
// ReactDOM.render(React.createElement(App)
// , document.getElementById('root'));
ReactDOM.render(<App/>
, document.getElementById('root'));