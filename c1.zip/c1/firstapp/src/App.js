import React from 'react';
import './App.css';
import { Footer } from './components/Footer';
import {Header} from './components/Header';

const message = ()=>"Hi React JS $$$$$$";

 const MAX  = 100;
  const App=()=>{
  // <body bgcolor> <input type='text' placeholder=''/>
  // <h1 >Hello ReactJS</h1>
  const myStyle = {
    backgroundColor:'red',
    color:'yellow'
  }
  let title  = 'Hello React JS.....';
  return (
    <div>
      <Header/>
    <h1 style={myStyle}>{title}</h1>
    <h1 className='red'>{message()}</h1>
    <Footer/>
    </div>
    /*
    React.createElement('div',null,
      React.createElement('h1',null,'Hello ReactJS'),
      React.createElement('h1',null,'Hi ReactJS')
      )*/


  );
}
// const OBJ = {
//   App, MAX
// }
//export default OBJ;



export default App;