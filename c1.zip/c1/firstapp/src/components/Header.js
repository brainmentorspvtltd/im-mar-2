import React from 'react';
export const Header = ()=>{
    return (<p>I am a Header</p>);
}