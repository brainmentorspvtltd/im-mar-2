import React from 'react';
export const Footer = ()=>{
    return (<p>I am a Footer</p>);
}