export const constants = {
    title :'Greet-App'
}