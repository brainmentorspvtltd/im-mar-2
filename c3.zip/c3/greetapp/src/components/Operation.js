import React from 'react'

export const  Operation=(props)=> {

    const className = `btn btn-${props.type} me-2`;
    return (
        <>
            <button onClick={props.call} className={className}>{props.lbl}</button>
        </>
    )
}
