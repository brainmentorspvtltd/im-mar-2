import React from 'react'

export const  Output=(props)=> {


    return (
        <>
            {props.msg}
        </>
    )
}
