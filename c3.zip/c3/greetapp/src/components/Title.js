import React from 'react'

export const Title=(props)=> {


    return (
        <h1 className='alert-info text-center'>{props.title}</h1>
    )
}
