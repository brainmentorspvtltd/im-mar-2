import React from 'react';
import Greet from './containers/Greet';
import { constants } from './utils/constants';
const App = ()=>{
  return (<Greet title = {constants.title}/>);
}
export default App;