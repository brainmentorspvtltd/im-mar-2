import React, { Component } from 'react'
import { Input } from '../components/Input';
import { Operation } from '../components/Operation';
import { Output } from '../components/Output';
import { Title } from '../components/Title';

export default class Greet extends Component {
    constructor(props) {
        super(props); // props = {}
       // this.title = 'Greet App...';
       this.firstName = '';
       this.lastName = '';
        this.state = {
            msg :''
        }


    }

    makeFullName(){
        let fullName = this.initCap(this.firstName) + ' ' + this.initCap(this.lastName);
        this.setState({msg:`Welcome ${fullName}`});
    }

    clearAll(){

    }

    initCap(str){ // amit - a - 0 A   mit
        return str.charAt(0).toUpperCase() + str.substring(1).toLowerCase();
    }

    takeFirstName(event){
        console.log('FNAME ',event.target.value);
        this.firstName = event.target.value;
    }

    takeLastName(event){
        console.log('LNAME', event.target.value);
        this.lastName = event.target.value;
    }


    render() {
         //Title({title:'Greet App'})
        return (
            <>
                <div className = 'container'>
                <Title title={this.props.title}/>
                <Input input={this.takeFirstName.bind(this)} lbl = 'First Name'/>
                <Input input = {this.takeLastName.bind(this)} lbl = 'Last Name'/>
                <br/>
                <Operation call={this.makeFullName.bind(this)} type='primary' lbl = 'Greet'/>
                <Operation call={this.clearAll} type='danger' lbl ='Clear All'/>
                <br/>
                <br/>
                <Output msg={this.state.msg}/>

                </div>
            </>
        )
    }
}
