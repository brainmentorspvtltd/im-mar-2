import React from 'react'

export const Input=(props)=> {
    const placeHolder = `Type ${props.lbl} Here`;

    return (
        <div className = 'form-group'>
          <label>{props.lbl}</label>
          <input value={props.val}  onChange={props.input} className = 'form-control' type ='text' placeholder={placeHolder}/>
        </div>
    )
}
